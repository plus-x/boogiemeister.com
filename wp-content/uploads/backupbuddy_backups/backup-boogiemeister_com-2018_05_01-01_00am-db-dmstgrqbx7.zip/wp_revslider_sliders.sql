CREATE TABLE `wp_revslider_sliders` (  `id` int(9) NOT NULL AUTO_INCREMENT,  `title` tinytext NOT NULL,  `alias` tinytext,  `params` text NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_revslider_sliders` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_revslider_sliders` ENABLE KEYS */;
