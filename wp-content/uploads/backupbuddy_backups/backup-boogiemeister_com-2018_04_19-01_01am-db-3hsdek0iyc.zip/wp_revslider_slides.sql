CREATE TABLE `wp_revslider_slides` (  `id` int(9) NOT NULL AUTO_INCREMENT,  `slider_id` int(9) NOT NULL,  `slide_order` int(11) NOT NULL,  `params` text NOT NULL,  `layers` text NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_revslider_slides` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_revslider_slides` ENABLE KEYS */;
