CREATE TABLE `wp_revslider_layer_animations` (  `id` int(9) NOT NULL AUTO_INCREMENT,  `handle` text NOT NULL,  `params` text NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_revslider_layer_animations` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_revslider_layer_animations` ENABLE KEYS */;
